import colab_window
import pygame
import math  # (cambio web) para dibujar estrellas

pygame.init()
pygame.font.init()

# --- Ventana ---
ANCHO, ALTO = 680, 420
pantalla = pygame.display.set_mode((ANCHO, ALTO))
pygame.display.set_caption("Dear Witch")
reloj = pygame.time.Clock()

# --- Paleta de colores Aesthetic / Niñas Pro ---
NAVY = (23, 25, 41)
PURPLE_PASTEL = (75, 55, 105)
CARD_BG = (35, 30, 55)
BLANCO = (245, 245, 245)
AMARILLO = (253, 202, 54)
VERDE = (46, 204, 113)
ROJO = (231, 76, 60)
ROSA = (233, 30, 99)

# --- Tipografías ---
fuente_titulo = pygame.font.SysFont("arial", 24, bold=True)
fuente_pregunta = pygame.font.SysFont("arial", 20, bold=True)
fuente_opciones = pygame.font.SysFont("arial", 18)
fuente_mini = pygame.font.SysFont("arial", 13, bold=True)

# --- Imagen del recetario (hecha en Canva) ---
ANCHO_REC, ALTO_REC = 510, 315
img_recetario = pygame.image.load("recetario.png")
img_recetario = pygame.transform.scale(img_recetario, (ANCHO_REC, ALTO_REC))

# --- Imagen del Caldero ---
ANCHO_CAL, ALTO_CAL = 130, 130
img_caldero = pygame.image.load("caldero.png").convert_alpha()
img_caldero = pygame.transform.scale(img_caldero, (ANCHO_CAL, ALTO_CAL))

# --- Imagenes del juego ---
# --- 🚨 Ingresa aqui el nombre de la imagen de inicio  ---
imagenes_fondo = {}
nombres_imagenes = ["pantalla-inicio.png", "fondo.jpg","recetario.png","Cliente_1.jpg", "Cliente_2.jpg", "Cliente_3.jpg", "Cliente_4.jpg", "Cliente_5.jpg","Cliente_6.jpg"]
for nombre in nombres_imagenes:
    try:
        img = pygame.image.load(nombre)
        imagenes_fondo[nombre] = pygame.transform.scale(img, (ANCHO, ALTO))
    except Exception:
        imagenes_fondo[nombre] = None

# --- Imágenes de los ingredientes (para la cuadrícula) ---
TAMANO_ICONO = 36
imagenes_ingredientes = {}
LISTA_INGREDIENTES = ["cuerno_unicornio", "flor_celeste", "flor_loto", "hierba", "hoja","hongos", "ojo", "planta_carnivora", "pluma", "slime"]
for nombre in LISTA_INGREDIENTES:
    try:
        img = pygame.image.load(nombre + ".png").convert_alpha()
        imagenes_ingredientes[nombre] = pygame.transform.scale(img, (TAMANO_ICONO, TAMANO_ICONO))
    except Exception:
        imagenes_ingredientes[nombre] = None

# --- 🚨 COMPLETAR AQUI LOS COMANDOS PARA LOS INGREDIENTES y las opciones y respuestas de cada cliente ---

INGREDIENTES = {}
numero = 0
for nombre in LISTA_INGREDIENTES:
    INGREDIENTES[numero] = nombre
    numero += 1

TECLAS_NUMERO = {
    pygame.K_0: 0, pygame.K_1: 1, pygame.K_2: 2, pygame.K_3: 3, pygame.K_4: 4,
    pygame.K_5: 5, pygame.K_6: 6, pygame.K_7: 7, pygame.K_8: 8, pygame.K_9: 9
}


# --- Clientes ---
#🚨 Hint en opciones puedes indicar los numeros que deben seleccionar para la respuesta correcta

clientes = [
    {
        "texto": "Cliente1: Quiero ganarme su corazón y sembrarlo en las estrellas... Necesito en mí la ligereza de un ave y la flor que flota serenamente en el estanque del bosque.",
        "opciones": ["Poción de amor", "Poción de levitación", "Poción de odio"],
        "pocion_correcta": "pocion_de_amor",
        "imagen": "Cliente_1.jpg"
    },
    {
        "texto": "Cliente2: Mis ojos pesan pero mi mente no se apaga... Mezcla aquello que crece en las sombras y la humedad frente al frescor del pasto verde para poder descansar.",
        "opciones": ["Poción de amor", "Poción de levitación", "Poción de odio"],
        "pocion_correcta": "pocion_de_sueño",
        "imagen": "Cliente_2.jpg"
    },
    {
        "texto": "Cliente3: Mi vida se me escapa por mis heridas... Dame la pureza de la gran bestia y la belleza de la flor acuática para curarme.",
        "opciones": ["Poción de amor", "Poción de levitación", "Poción de odio"],
        "pocion_correcta": "pocion_de_curacion",
        "imagen": "Cliente_3.jpg"
    },
    {
        "texto": "Cliente4: Deberé de cruzar el abismo sin tocar el suelo... Dame el plumaje que surca en el aire mezclado con la flor del color del cielo.",
        "opciones": ["Poción de amor", "Poción de levitación", "Poción de odio"],
        "pocion_correcta": "pocion_de_levitacion",
        "imagen": "Cliente_4.jpg"
    },
    {
        "texto": "Cliente5: Deseo sembrar los males y la amargura en este mundo... Junta la mirada que todo observa con el apetito mordaz de la flor voraz.",
        "opciones": ["Poción de amor", "Poción de levitación", "Poción de odio"],
        "pocion_correcta": "pocion_de_odio",
        "imagen": "Cliente_5.jpg"
    },
    {
        "texto": "Cliente6: Para servir a mi pueblo me enfrentaré a una bestia gigante... Mezcla la esencia pegajosa con una hoja de los árboles ancianos y el mordisco del monstruo vegetal.",
        "opciones": ["Poción de amor", "Poción de levitación", "Poción de odio"],
        "pocion_correcta": "pocion_de_fuerza",
        "imagen": "Cliente_6.jpg"
    }
]

# --- Variables del juego ---
indice_cliente = 0
clientes_atendidos = 0
vidas = 3
caldero = []
feedback = None
esperando_siguiente = False
tiempo_feedback = 0
mostrando_instructivo = False
puntaje = 0
caldero = []
pantalla_inicio = True

#Diccionario
RECETAS = {
    "pocion_de_amor": ["flor_loto", "pluma"],
    "pocion_de_sueño": ["hongos", "hierba"],
    "pocion_de_curacion": ["cuerno_unicornio", "flor_loto"],
    "pocion_de_levitacion": ["pluma", "flor_celeste"],
    "pocion_de_odio": ["ojo", "planta_carnivora"],
    "pocion_de_fuerza": ["slime", "hoja", "planta_carnivora"]
}

#Funciones

# (cambio web) Los emojis se ven como cuadraditos en el navegador,
# así que se dibujan con figuras de pygame.
def dibujar_estrella(superficie, color, centro, radio):
  puntos = []
  for i in range(10):
    angulo = math.pi / 2 + i * math.pi / 5
    r = radio if i % 2 == 0 else radio * 0.45
    puntos.append((centro[0] + r * math.cos(angulo), centro[1] - r * math.sin(angulo)))
  pygame.draw.polygon(superficie, color, puntos)

def dibujar_cruz(superficie, color, centro, tamano):
  x, y = centro
  pygame.draw.line(superficie, color, (x - tamano, y - tamano), (x + tamano, y + tamano), 4)
  pygame.draw.line(superficie, color, (x - tamano, y + tamano), (x + tamano, y - tamano), 4)

def agregar_ingredientes(lista_ingredientes, ingrediente_nuevo):
  lista_ingredientes.append(ingrediente_nuevo)
  lista_ingredientes.sort()
  return lista_ingredientes

def verificar_respuesta(lista_ingredientes, respuesta_correcta):
  ingredientes_esperados = RECETAS[respuesta_correcta]

  if sorted(lista_ingredientes) == sorted(ingredientes_esperados):
    return True
  else:
    return False


# --- Bucle principal del juego ---
corriendo = True
while corriendo:
    tiempo_actual = pygame.time.get_ticks()

    # 1) Control de Eventos
    for evento in pygame.event.get():
        if evento.type == pygame.QUIT:
            corriendo = False
        if evento.type == pygame.KEYDOWN:
            # --- 🚨 COMPLETAR AQUI: comando para empezar el juego ---
            if pantalla_inicio:
              if evento.key == pygame.K_RETURN:
                pantalla_inicio = False

            # Al presionar BARRA ESPACIADORA, alterna el instructivo
            elif evento.key == pygame.K_SPACE:
              mostrando_instructivo = not mostrando_instructivo
            # Reiniciar juego si terminó
            elif indice_cliente >= len(clientes) and evento.key == pygame.K_r:
              indice_cliente = 0
              puntaje = 0
              feedback = None
              esperando_siguiente = False
              caldero = []

            # --- 🚨 COMPLETAR AQUI: #Aqui debes modificar los comandos de las opciones de ingredientes con las teclas del computado ---
            elif not mostrando_instructivo and not esperando_siguiente and indice_cliente < len(clientes):
              if evento.key in TECLAS_NUMERO:
                numero_tecla = TECLAS_NUMERO[evento.key]
                ingrediente = INGREDIENTES[numero_tecla]
                if ingrediente in caldero:
                  caldero.remove(ingrediente)
                else:
                  caldero = agregar_ingredientes(caldero, ingrediente)

              elif evento.key == pygame.K_d:
                caldero = []


              # --- 🚨 Hint: COMPLETAR para comprobar la combinación del caldero
              elif evento.key == pygame.K_RETURN and len(caldero) > 0:
                pregunta_actual = clientes[indice_cliente]
                if verificar_respuesta(caldero, pregunta_actual["pocion_correcta"]):
                  feedback = "bien"
                  puntaje += 10
                else:
                  feedback = "mal"

                caldero = []
                esperando_siguiente = True
                tiempo_feedback = tiempo_actual

    # Avanzar a la siguiente pregunta tras 1.2 segundos de mostrar el resultado
    if not mostrando_instructivo and esperando_siguiente and tiempo_actual - tiempo_feedback > 1200:
        indice_cliente += 1
        feedback = None
        esperando_siguiente = False

    # 2) Dibujar Fondo
    pantalla.fill(CARD_BG)

    if pantalla_inicio:
      img_inicio = imagenes_fondo.get("pantalla-inicio.png")
      if img_inicio:
        pantalla.blit(img_inicio, (0, 0))

      rect_inicio = pygame.Rect(90, 110, ANCHO - 180, ALTO - 220)

    # --- 🚨 COMPLETAR AQUI: #Aqui debes agregar la pestaña de inicio y el comando para que empiece el juego. ---
    # (Nota: Crea una variable de estado como 'pantalla_inicio = True' arriba y cambia su valor con una tecla en Control de Eventos)

    elif indice_cliente < len(clientes):
      nombre_img = clientes[indice_cliente]["imagen"]
      img_actual = imagenes_fondo.get(nombre_img)
      if img_actual:
        pantalla.blit(img_actual, (0, 0))
    # JUEGO ACTIVO
        # Header: Título y Puntaje (con tarjetas para legibilidad)
        txt_ayuda = fuente_pregunta.render("Presiona [ESPACIO] para ver instrucciones", True, ROSA)
        txt_puntaje = fuente_opciones.render(f"Puntos: {puntaje}", True, ROSA)
        pantalla.blit(txt_ayuda, (45, 23))
        pantalla.blit(txt_puntaje, (ANCHO - 150, 26))

        p_actual = clientes[indice_cliente]

        # Tarjeta de Pregunta
        rect_pregunta = pygame.Rect(20, 65, 330, 130)
        pygame.draw.rect(pantalla, CARD_BG, rect_pregunta, border_radius=12)

        # Dividir el texto largo en varias líneas para que quepa en el cuadro izquierdo
        palabras = p_actual["texto"].split(" ")
        lineas = []
        linea_actual = ""
        for palabra in palabras:
            prueba = linea_actual + palabra + " "
            if fuente_mini.size(prueba)[0] < 330 - 20:
                linea_actual = prueba
            else:
                lineas.append(linea_actual)
                linea_actual = palabra + " "
        lineas.append(linea_actual)

        y_texto = 75
        for linea in lineas:
            txt_linea = fuente_mini.render(linea, True, BLANCO)
            pantalla.blit(txt_linea, (30, y_texto))
            y_texto += 18

        # Dibujar el Caldero entre el cuadro de texto y la barra de ingredientes
        x_caldero = 150
        y_caldero = 200
        pantalla.blit(img_caldero, (x_caldero, y_caldero))

        # NUEVO: cartel al lado del caldero que explica qué hace cada tecla
        rect_teclas = pygame.Rect(295, 225, 210, 50)
        pygame.draw.rect(pantalla, NAVY, rect_teclas, border_radius=10)
        txt_enter = fuente_mini.render("[ENTER] Preparar poción", True, BLANCO)
        txt_borrar = fuente_mini.render("[D] Vaciar caldero", True, BLANCO)
        pantalla.blit(txt_enter, (305, 233))
        pantalla.blit(txt_borrar, (305, 253))
        # --------------------------------------------------------------

        # Tarjetas de Opciones

        tamano_celda = 56
        espacio = 8
        total_casillas = 10

        ancho_total = total_casillas * tamano_celda + (total_casillas - 1) * espacio
        x_inicio = (ANCHO - ancho_total) // 2
        y_inicio = ALTO - tamano_celda - 15

        # Panel contenedor oscuro detrás de toda la fila
        panel_barra = pygame.Rect(x_inicio - 10, y_inicio - 8, ancho_total + 20, tamano_celda + 16)
        pygame.draw.rect(pantalla, NAVY, panel_barra, border_radius=12)
        pygame.draw.rect(pantalla, PURPLE_PASTEL, panel_barra, width=2, border_radius=12)

        for num in range(0, total_casillas):
            nombre_ing = INGREDIENTES[num]

            x = x_inicio + num * (tamano_celda + espacio)
            y = y_inicio
            rect_celda = pygame.Rect(x, y, tamano_celda, tamano_celda)

            # Fondo de cada casilla
            pygame.draw.rect(pantalla, CARD_BG, rect_celda, border_radius=8)

            # Borde iluminado si el ingrediente está en el caldero
            if nombre_ing in caldero:
                pygame.draw.rect(pantalla, AMARILLO, rect_celda, width=3, border_radius=8)
            else:
                pygame.draw.rect(pantalla, PURPLE_PASTEL, rect_celda, width=2, border_radius=8)

            # --- DIBUJAR IMAGEN DEL INGREDIENTE EN LA CASILLA ---
            img_ing = imagenes_ingredientes.get(nombre_ing)
            if img_ing is not None:
                offset_x = (tamano_celda - TAMANO_ICONO) // 2
                offset_y = (tamano_celda - TAMANO_ICONO) // 2 + 3
                pantalla.blit(img_ing, (x + offset_x, y + offset_y))
            else:
                # Si no encuentra el archivo .png, muestra las 4 primeras letras para identificarla
                etiqueta = nombre_ing[:4].upper()
                txt_err = fuente_mini.render(etiqueta, True, AMARILLO)
                pantalla.blit(txt_err, (x + 10, y + 22))

            # Número de tecla (1 al 9, y 0 para el 10) en la esquina superior izquierda
            txt_num = fuente_mini.render(str(num), True, BLANCO)
            pantalla.blit(txt_num, (x + 5, y + 2))

        # Feedback
        if feedback == "bien":
            rect_fb = pygame.Rect(30, 335, ANCHO - 60, 45)
            pygame.draw.rect(pantalla, CARD_BG, rect_fb, border_radius=10)
            msg = fuente_pregunta.render("¡Correcto! +10 pts", True, VERDE)
            pantalla.blit(msg, (45, 345))
            dibujar_estrella(pantalla, AMARILLO, (45 + msg.get_width() + 20, 345 + msg.get_height() // 2), 12)
        elif feedback == "mal":
            rect_fb = pygame.Rect(30, 335, ANCHO - 60, 45)
            pygame.draw.rect(pantalla, CARD_BG, rect_fb, border_radius=10)
            msg = fuente_pregunta.render("¡Ups! Respuesta incorrecta", True, ROJO)
            pantalla.blit(msg, (45, 345))
            dibujar_cruz(pantalla, ROJO, (45 + msg.get_width() + 20, 345 + msg.get_height() // 2), 8)

    # PANTALLA DE RESULTADOS
    else:
        rect_final = pygame.Rect(60, 60, ANCHO - 120, ALTO - 120)
        pygame.draw.rect(pantalla, CARD_BG, rect_final, border_radius=16)

        txt_fin = fuente_titulo.render("¡TRIVIA COMPLETADA!", True, AMARILLO)
        txt_score = fuente_pregunta.render(f"Puntaje Final: {puntaje} / {len(clientes) * 10} pts", True, BLANCO)
        txt_restart = fuente_opciones.render("Presiona 'R' para jugar de nuevo", True, ROSA)

        pantalla.blit(txt_fin, (ANCHO // 2 - txt_fin.get_width() // 2, 120))
        y_estrellas = 120 + txt_fin.get_height() // 2
        dibujar_estrella(pantalla, AMARILLO, (ANCHO // 2 - txt_fin.get_width() // 2 - 25, y_estrellas), 12)
        dibujar_estrella(pantalla, AMARILLO, (ANCHO // 2 + txt_fin.get_width() // 2 + 25, y_estrellas), 12)
        pantalla.blit(txt_score, (ANCHO // 2 - txt_score.get_width() // 2, 190))
        pantalla.blit(txt_restart, (ANCHO // 2 - txt_restart.get_width() // 2, 260))

    #  NUEVO: Tarjeta superpuesta del INSTRUCTIVO (se dibuja al final para quedar encima de todo)
    if mostrando_instructivo:
      x_rec = (ANCHO - ANCHO_REC) // 2
      y_rec = (ALTO - ALTO_REC) // 2
      pantalla.blit(img_recetario, (x_rec, y_rec))

    pygame.display.flip()
    reloj.tick(60)

pygame.quit()