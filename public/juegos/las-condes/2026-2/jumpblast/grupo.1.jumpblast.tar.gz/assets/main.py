"""Envoltorio para jugar en el navegador con pygbag un juego escrito en Google Colab.

El juego original (GAME_FILE) no se modifica. Este archivo:

1. Reemplaza `colab_window` por una versión mínima que solo entrega `pygame`.
   En el navegador no hay Xvfb, VNC ni pip: el `colab_window` real no sirve.
2. Crea `pygame.locals` si falta.
3. Cambia el directorio de trabajo a la carpeta del juego, para que
   `pygame.image.load("imagen.png")` encuentre los archivos.
4. Transforma el código con `ast`:
   - Las funciones que tienen el bucle del juego (un `while` que llama a
     `display.flip()` o `display.update()`) pasan a `async def`, y también las
     funciones que las llaman. Sus llamadas reciben `await`.
   - Cada `while` que dibuja en pantalla recibe `await asyncio.sleep(0)` AL
     PRINCIPIO, para que un `continue` no se lo salte.
   - `time.sleep(x)` pasa a `await asyncio.sleep(x)` (donde se puede usar await).
5. Ejecuta el código con "await" permitido al nivel superior, así las variables
   globales del juego siguen siendo globales (los `global x` funcionan igual).

Limitación: no detecta bucles de juego dentro de métodos de clases.
"""

import ast
import asyncio
import os
import sys
import types

import pygame

GAME_FILE = "juego.py"

# ───────────── colab_window falso ─────────────
_colab = types.ModuleType("colab_window")
_colab.pygame = pygame
_colab.en_colab = lambda: False
_colab.mostrar = lambda *a, **k: None
_colab.diagnostico = lambda *a, **k: None
_colab.__all__ = ["pygame", "diagnostico", "mostrar"]
sys.modules["colab_window"] = _colab

# ───────────── pygame.locals ─────────────
try:
    import pygame.locals  # noqa: F401
except ImportError:
    _locals = types.ModuleType("pygame.locals")
    for _n in dir(pygame):
        if _n.isupper() or _n.startswith(("K_", "KMOD_")):
            setattr(_locals, _n, getattr(pygame, _n))
    sys.modules["pygame.locals"] = _locals
    pygame.locals = _locals

# ───────────── carpeta del juego ─────────────
BASE = os.path.dirname(os.path.abspath(__file__))
os.chdir(BASE)


# ───────────── transformación del código ─────────────
def _dibuja(nodo):
    """¿Hay dentro una llamada a algo.flip() o algo.update() de display?"""
    for n in ast.walk(nodo):
        if (isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)
                and n.func.attr in ("flip", "update")):
            return True
    return False


def _es_bucle_juego(nodo):
    return isinstance(nodo, ast.While) and _dibuja(nodo)


def _funciones(arbol):
    """Funciones (no métodos) del archivo, por nombre."""
    resultado = {}

    def visitar(cuerpo):
        for n in cuerpo:
            if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
                resultado[n.name] = n
                visitar(n.body)
            elif isinstance(n, ast.ClassDef):
                continue
            else:
                for campo in ("body", "orelse", "finalbody", "handlers"):
                    visitar(getattr(n, campo, []) or [])

    visitar(arbol.body)
    return resultado


def _nombres_llamados(func):
    return {n.func.id for n in ast.walk(func)
            if isinstance(n, ast.Call) and isinstance(n.func, ast.Name)}


def _funciones_async(arbol):
    funcs = _funciones(arbol)
    marcadas = {nombre for nombre, f in funcs.items()
                if any(_es_bucle_juego(n) for n in ast.walk(f))}
    cambio = True
    while cambio:  # quien llama a una función async también debe ser async
        cambio = False
        for nombre, f in funcs.items():
            if nombre not in marcadas and _nombres_llamados(f) & marcadas:
                marcadas.add(nombre)
                cambio = True
    return marcadas


def _sleep0():
    return ast.parse("await asyncio.sleep(0)").body[0]


class _Transformador(ast.NodeTransformer):
    def __init__(self, asincronas):
        self.asincronas = asincronas
        self.puede_await = [True]  # nivel superior: sí (PyCF_ALLOW_TOP_LEVEL_AWAIT)

    def _en_scope(self, nodo, puede):
        self.puede_await.append(puede)
        self.generic_visit(nodo)
        self.puede_await.pop()
        return nodo

    def visit_FunctionDef(self, nodo):
        if nodo.name in self.asincronas:
            nuevo = ast.AsyncFunctionDef(**{c: getattr(nodo, c, None)
                                            for c in nodo._fields})
            ast.copy_location(nuevo, nodo)
            return self._en_scope(nuevo, True)
        return self._en_scope(nodo, False)

    def visit_AsyncFunctionDef(self, nodo):
        return self._en_scope(nodo, True)

    def visit_Lambda(self, nodo):
        return self._en_scope(nodo, False)

    def visit_ClassDef(self, nodo):
        return self._en_scope(nodo, False)

    def visit_While(self, nodo):
        es_juego = _es_bucle_juego(nodo)
        self.generic_visit(nodo)
        if es_juego and self.puede_await[-1]:
            nodo.body.insert(0, _sleep0())
        return nodo

    def visit_Call(self, nodo):
        self.generic_visit(nodo)
        if not self.puede_await[-1]:
            return nodo
        f = nodo.func
        if isinstance(f, ast.Name) and f.id in self.asincronas:
            return ast.Await(value=nodo)
        if (isinstance(f, ast.Attribute) and f.attr == "sleep"
                and isinstance(f.value, ast.Name) and f.value.id == "time"):
            nodo.func = ast.Attribute(value=ast.Name(id="asyncio", ctx=ast.Load()),
                                      attr="sleep", ctx=ast.Load())
            return ast.Await(value=nodo)
        return nodo


def _preparar(codigo, nombre):
    arbol = ast.parse(codigo, nombre)
    arbol = _Transformador(_funciones_async(arbol)).visit(arbol)
    ast.fix_missing_locations(arbol)
    return compile(arbol, nombre, "exec", flags=ast.PyCF_ALLOW_TOP_LEVEL_AWAIT)


async def main():
    ruta = os.path.join(BASE, GAME_FILE)
    with open(ruta, encoding="utf-8") as f:
        codigo = _preparar(f.read(), ruta)
    espacio = {"__name__": "__main__", "__file__": ruta,
               "__builtins__": __builtins__, "asyncio": asyncio}
    resultado = eval(codigo, espacio)
    if asyncio.iscoroutine(resultado):
        await resultado


asyncio.run(main())
