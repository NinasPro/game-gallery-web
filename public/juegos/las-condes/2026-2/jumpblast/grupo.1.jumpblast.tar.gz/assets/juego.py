from typing import Text
import pygame
import random
import colab_window

pygame.init()
pygame.font.init()

# ==========================================
# ⚙️ ETAPA 1: Ventana, Reloj y Colores
# ==========================================
ANCHO, ALTO = 640, 400
pantalla = pygame.display.set_mode((ANCHO, ALTO))
pygame.display.set_caption("JumpBlast - Niñas Pro")  # (cambio web) antes "Runner & Shooter 🚀 - Niñas Pro"
reloj = pygame.time.Clock()

NAVY = (23, 25, 41)
LINEAS_FONDO = (38, 42, 68)
ROSA = (233, 30, 99)
PURPURA = (107, 50, 237)
AMARILLO = (253, 202, 54)
CELESTE = (0, 188, 212)
BLANCO = (245, 245, 245)
VERDE = (76, 217, 100)
ROJO_FONDO = (90, 30, 40)
CARD_BG = (70, 24, 105)
ROJO = (231, 76, 60)

fuente = pygame.font.SysFont("arial", 20, bold=True)
fuente_grande = pygame.font.SysFont("arial", 32, bold=True)
fuente_media = pygame.font.SysFont("arial", 22, bold=True)
fuente_peque = pygame.font.SysFont("arial", 18)

# ==========================================
# Cargar imagenes
# ==========================================
# VIDAS
corazon_img = pygame.image.load("corazon.png").convert_alpha()
corazon_img = pygame.transform.scale(corazon_img, (24, 24))

# ENEMIGOS
enemigos_img = pygame.image.load("enemigo.png").convert_alpha()
enemigos_img = pygame.transform.scale(enemigos_img, (32, 32))

# PERSONAJE PRINCIPAL
principal_img = pygame.image.load("pixil-frame-0 (8).png").convert_alpha()
principal_img = pygame.transform.scale(principal_img, (40, 40))


#PLATAFORMAS
plataforma_img = pygame.image.load("plataforma.png").convert_alpha()
plataforma_img = pygame.transform.scale(plataforma_img, (130, 22))

#FONDO
fondo_img = pygame.image.load("fondo.jpg").convert_alpha()
fondo_img = pygame.transform.scale(fondo_img, (ANCHO, ALTO))  # (cambio web) decía fondon_img y el fondo no se escalaba

fondo_victoria_img = pygame.image.load("fondo_victoria.png").convert()
fondo_victoria_img = pygame.transform.scale(fondo_victoria_img, (ANCHO, ALTO))


# Emojis
cara_triste_img = pygame.image.load("caratriste.png").convert_alpha()
cara_triste_img = pygame.transform.scale(cara_triste_img, (56, 56))

emoji_frustrado = pygame.image.load("emoji_frustrado.png").convert_alpha()
emoji_frustrado = pygame.transform.scale(emoji_frustrado, (32, 32))

emoji_brillo = pygame.image.load("emoji_brillo.png").convert_alpha()
emoji_brillo = pygame.transform.scale(emoji_brillo, (32, 32))

# ==========================================
# 👾 ETAPA 2: Jugadora, Plataformas y Enemigos
# ==========================================
jugadora = pygame.Rect(80, 200, 35, 35)
VELOCIDAD_X = 4
vel_y = 0
GRAVEDAD = 0.65
FUERZA_SALTO = -13.5
frames_en_aire = 0

estrellas = [[random.randint(0, ANCHO), random.randint(20, ALTO - 40)] for _ in range(12)]

piso = pygame.Rect(0, ALTO - 20, ANCHO, 20)
# (cambio web) posiciones guardadas para volver a ponerlas al reiniciar
POS_PLATAFORMAS = [(220, 295), (430, 215), (640, 135)]
plataformas = [pygame.Rect(x, y, 130, 22) for x, y in POS_PLATAFORMAS]

balas = []
VELOCIDAD_BALA = 7
ALTURAS_ENEMIGOS = [345, 260, 180, 100]
enemigos = [
    pygame.Rect(ANCHO + 100, 345, 32, 32),
    pygame.Rect(ANCHO + 320, 260, 32, 32),
    pygame.Rect(ANCHO + 540, 180, 32, 32),
]

VIDA_ENEMIGO = 3
vidas_enemigos = [VIDA_ENEMIGO] * len(enemigos)
DISTANCIA_MIN = 200

puntaje = 0
vidas = 3
estado = "INICIO"


def reaparecer(enemigo):
    otros = [e for e in enemigos if e is not enemigo]
    mas_a_la_derecha = max(e.right for e in otros) if otros else ANCHO
    enemigo.left = max(ANCHO + 40, mas_a_la_derecha + DISTANCIA_MIN + random.randint(0, 80))
    enemigo.y = random.choice(ALTURAS_ENEMIGOS)
    vidas_enemigos[enemigos.index(enemigo)] = VIDA_ENEMIGO


def reiniciar_juego():
    global puntaje, vidas, estado, balas, vel_y, frames_en_aire
    puntaje = 0
    vidas = 3
    balas = []
    vel_y = 0
    frames_en_aire = 0
    jugadora.x = 80
    jugadora.y = 200
    for plat, pos in zip(plataformas, POS_PLATAFORMAS):  # (cambio web) reiniciar plataformas
        plat.topleft = pos
    for i, e in enumerate(enemigos):
        e.x = ANCHO + 100 + i * 220
        e.y = ALTURAS_ENEMIGOS[i % len(ALTURAS_ENEMIGOS)]
        vidas_enemigos[i] = VIDA_ENEMIGO
    estado = "JUGANDO"


def dibujar_vidas(x, y, cantidad, tamaño=24, separacion=6):
    for i in range(cantidad):
        pantalla.blit(corazon_img, (x + i * (tamaño + separacion), y))


# ==========================================
# 🔄 BUCLE PRINCIPAL
# ==========================================
corriendo = True
while corriendo:
    for evento in pygame.event.get():
        if evento.type == pygame.QUIT:
            corriendo = False

        if evento.type == pygame.KEYDOWN:
            if evento.key == pygame.K_p:
                if estado == "JUGANDO":
                    estado = "PAUSA"
                elif estado == "PAUSA":
                    estado = "JUGANDO"

            if evento.key == pygame.K_ESCAPE:
                corriendo = False

            if evento.key == pygame.K_SPACE:
                if estado == "INICIO":
                    estado = "JUGANDO"
                elif estado == "GAME_OVER" or estado == "VICTORIA":
                    reiniciar_juego()

            # Disparar con las flechas
            if estado == "JUGANDO":
                if evento.key == pygame.K_RIGHT:
                    rect = pygame.Rect(jugadora.right, jugadora.centery - 4, 14, 8)
                    balas.append([rect, VELOCIDAD_BALA, 0])
                if evento.key == pygame.K_LEFT:
                    rect = pygame.Rect(jugadora.left - 14, jugadora.centery - 4, 14, 8)
                    balas.append([rect, -VELOCIDAD_BALA, 0])
                if evento.key == pygame.K_UP:
                    rect = pygame.Rect(jugadora.centerx - 4, jugadora.top - 14, 8, 14)
                    balas.append([rect, 0, -VELOCIDAD_BALA])

    if vidas <= 0:
        estado = "GAME_OVER"

    if puntaje >= 100 and estado == "JUGANDO":
        estado = "VICTORIA"

    teclas = pygame.key.get_pressed()
    if estado == "JUGANDO":
        if (teclas[pygame.K_w] and frames_en_aire < 5) or (teclas[pygame.K_SPACE] and frames_en_aire < 5):
            vel_y = FUERZA_SALTO
            frames_en_aire = 10

        if teclas[pygame.K_a]:
            jugadora.x -= VELOCIDAD_X
        if teclas[pygame.K_d]:
            jugadora.x += VELOCIDAD_X
        jugadora.x = max(0, min(jugadora.x, ANCHO - jugadora.width))

        for bala in balas[:]:
            for plat in plataformas:
                if bala[0].colliderect(plat):
                    balas.remove(bala)
                    break

        for estrella in estrellas:
            estrella[0] -= 1
            if estrella[0] < 0:
                estrella[0] = ANCHO

        for plat in plataformas:
            plat.x -= 2
            if plat.right < 0:
                plat.left = ANCHO + 40

        vel_y += GRAVEDAD
        jugadora.y += int(vel_y)
        frames_en_aire += 1

        for superficie in [piso] + plataformas:
            if jugadora.colliderect(superficie) and vel_y >= 0:
                if jugadora.bottom - vel_y <= superficie.top + 8:
                    jugadora.bottom = superficie.top
                    vel_y = 0
                    frames_en_aire = 0

        for bala in balas[:]:
            bala[0].x += bala[1]
            bala[0].y += bala[2]
            if (bala[0].left > ANCHO or bala[0].right < 0
                    or bala[0].bottom < 0 or bala[0].top > ALTO):
                balas.remove(bala)

        for i, enemigo in enumerate(enemigos):
            enemigo.x -= 2
            if enemigo.right < 0:
                reaparecer(enemigo)

            for bala in balas[:]:
                if bala[0].colliderect(enemigo):
                    balas.remove(bala)
                    vidas_enemigos[i] -= 1
                    if vidas_enemigos[i] <= 0:
                        puntaje += 10
                        reaparecer(enemigo)
                    break

            if jugadora.colliderect(enemigo):
                vidas -= 1
                reaparecer(enemigo)

# --------------------------------------
    # 🖼️ ETAPA 5: Dibujar en Pantalla
    # --------------------------------------
    pantalla.fill(NAVY)

    if estado == "INICIO":
        pantalla.blit(fondo_img, (0, 0))

        rect_card = pygame.Rect(50, 80, ANCHO - 100, ALTO - 160)
        pygame.draw.rect(pantalla, CARD_BG, rect_card, border_radius=16)
        pygame.draw.rect(pantalla, ROSA, rect_card, width=3, border_radius=16)

        # Textos
        titulo = fuente_grande.render("JUMBLAST", True, AMARILLO)
        instruccion1 = fuente_media.render("Presiona ESPACIO para Comenzar", True, BLANCO)
        instruccion2 = fuente_peque.render("WASD para Moverse  |  FLECHAS para Disparar", True, ROSA)
        instruccion3 = fuente_peque.render("¡Llega a los 100 puntos para ganar!", True, (242,12,168))

        pantalla.blit(titulo, (ANCHO // 2 - titulo.get_width() // 2, 130))
        pantalla.blit(instruccion1, (ANCHO // 2 - instruccion1.get_width() // 2, 195))
        pantalla.blit(instruccion2, (ANCHO // 2 - instruccion2.get_width() // 2, 225))
        pantalla.blit(instruccion3, (ANCHO // 2 - instruccion3.get_width() // 2, 250))

    elif estado == "JUGANDO":
        pantalla.blit(fondo_img, (0, 0))
        pygame.draw.rect(pantalla, PURPURA, piso)
        for plat in plataformas:
            pantalla.blit(plataforma_img, plat)

        pantalla.blit(principal_img, jugadora)

        for bala in balas:
            pygame.draw.rect(pantalla, AMARILLO, bala[0], border_radius=3)

        for i, enemigo in enumerate(enemigos):
            pantalla.blit(enemigos_img, enemigo)

            ancho_barra, alto_barra = 34, 5
            x_barra = enemigo.centerx - ancho_barra // 2
            y_barra = enemigo.top - 10
            pygame.draw.rect(pantalla, ROJO_FONDO, (x_barra, y_barra, ancho_barra, alto_barra), border_radius=2)
            proporcion = max(0, vidas_enemigos[i]) / VIDA_ENEMIGO
            pygame.draw.rect(pantalla, VERDE, (x_barra, y_barra, int(ancho_barra * proporcion), alto_barra),
                             border_radius=2)

        # HUD: Puntos y corazones
        txt_puntos = fuente.render(f"Puntos: {puntaje}", True, BLANCO)
        pantalla.blit(txt_puntos, (15, 12))
        x_corazones = 15 + txt_puntos.get_width() + 20
        dibujar_vidas(x_corazones, 8, max(0, vidas))

        # Instrucciones
        txt_info = fuente_peque.render("[WASD] Mover | [Flechas] Disparar", True, BLANCO)
        pantalla.blit(txt_info, (ANCHO - txt_info.get_width() - 15, ALTO - 30))

    elif estado == "GAME_OVER":
        pantalla.fill(ROJO_FONDO)

        # Las 3 caras tristes arriba
        tam_cara = cara_triste_img.get_width()
        separacion_caras = 12
        ancho_total_caras = tam_cara * 3 + separacion_caras * 2
        x_inicio_caras = ANCHO // 2 - ancho_total_caras // 2
        y_caras = 32

        for i in range(3):
            x_cara = x_inicio_caras + i * (tam_cara + separacion_caras)
            pantalla.blit(cara_triste_img, (x_cara, y_caras))

        # Caja de texto
        CAJA_ROJO_OSCURO = (62, 10, 10)
        rect_card = pygame.Rect(65, 105, ANCHO - 130, 82)
        pygame.draw.rect(pantalla, CAJA_ROJO_OSCURO, rect_card, border_radius=24)
        pygame.draw.rect(pantalla, ROJO, rect_card, width=4, border_radius=24)

        # Titulo y emojis
        txt_game_over = fuente_grande.render("¡MISIÓN FALLIDA!", True, ROJO)

        espacio_emoji = 10
        w_emoji = emoji_frustrado.get_width()
        h_emoji = emoji_frustrado.get_height()

        w_texto = txt_game_over.get_width()
        h_texto = txt_game_over.get_height()

        # centrar titulo y emojis
        ancho_total = w_emoji + espacio_emoji + w_texto + espacio_emoji + w_emoji
        x_izq = ANCHO // 2 - ancho_total // 2
        x_txt = x_izq + w_emoji + espacio_emoji
        x_der = x_txt + w_texto + espacio_emoji

        y_txt = rect_card.centery - h_texto // 2
        y_emoji = rect_card.centery - h_emoji // 2

        pantalla.blit(emoji_frustrado, (x_izq, y_emoji))
        pantalla.blit(txt_game_over, (x_txt, y_txt))
        pantalla.blit(emoji_frustrado, (x_der, y_emoji))

        # Puntaje final y reiniciar
        txt_final = fuente_media.render(f"Puntaje Final: {puntaje} pts", True, BLANCO)
        txt_reiniciar = fuente_peque.render("Presiona ESPACIO para intentar de nuevo", True, AMARILLO)

        pantalla.blit(txt_final, (ANCHO // 2 - txt_final.get_width() // 2, 220))
        pantalla.blit(txt_reiniciar, (ANCHO // 2 - txt_reiniciar.get_width() // 2, 295))

    elif estado == "PAUSA":
        pantalla.blit(fondo_img, (0, 0))

        rect_card = pygame.Rect(50, 80, ANCHO - 100, ALTO - 160)
        pygame.draw.rect(pantalla, CARD_BG, rect_card, border_radius=16)
        pygame.draw.rect(pantalla, CELESTE, rect_card, width=3, border_radius=16)

        # Textos
        txt_pausa = fuente_grande.render("PAUSA", True, CELESTE)
        txt_instruccion = fuente_media.render("Presiona P para continuar", True, BLANCO)

        pantalla.blit(txt_pausa, (ANCHO // 2 - txt_pausa.get_width() // 2, 145))
        pantalla.blit(txt_instruccion, (ANCHO // 2 - txt_instruccion.get_width() // 2, 240))

    elif estado == "VICTORIA":
        pantalla.blit(fondo_victoria_img, (0, 0))

        rect_card = pygame.Rect(60, 85, ANCHO - 120, ALTO - 150)
        pygame.draw.rect(pantalla, (78, 36, 48), rect_card, border_radius=16)
        pygame.draw.rect(pantalla, (255, 118, 12), rect_card, width=4, border_radius=16)

        # Titulo y emojis
        txt_victoria = fuente_grande.render("¡VICTORIA!", True, (255, 246, 178))

        espacio = 10
        w_emoji = emoji_brillo.get_width()
        h_emoji = emoji_brillo.get_height()
        w_texto = txt_victoria.get_width()
        h_texto = txt_victoria.get_height()

        # centrar titulo y emojis
        ancho_total = w_emoji + espacio + w_texto + espacio + w_emoji
        x_inicio = ANCHO // 2 - ancho_total // 2
        y_fila = 125
        y_emoji = y_fila + (h_texto - h_emoji) // 2

        pantalla.blit(emoji_brillo, (x_inicio, y_emoji))
        pantalla.blit(txt_victoria, (x_inicio + w_emoji + espacio, y_fila))
        pantalla.blit(emoji_brillo, (x_inicio + w_emoji + espacio + w_texto + espacio, y_emoji))
        txt_final = fuente_media.render(f"Puntaje Final: {puntaje} pts", True, (250, 248, 255))
        txt_reiniciar = fuente_peque.render("Presiona ESPACIO para intentar de nuevo", True, (238, 214, 255))

        pantalla.blit(txt_final, (ANCHO // 2 - txt_final.get_width() // 2, 195))
        pantalla.blit(txt_reiniciar, (ANCHO // 2 - txt_reiniciar.get_width() // 2, 255))

    pygame.display.flip()
    reloj.tick(60)

pygame.quit()
