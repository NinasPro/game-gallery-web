import colab_window
import pygame
import random

pygame.init()

# ==========================================
# ⚙️ ETAPA 1: Ventana, Reloj y Colores
# ==========================================
ANCHO, ALTO = 600, 400
pantalla = pygame.display.set_mode((ANCHO, ALTO))
pygame.display.set_caption("Atrapa los deseos")
reloj = pygame.time.Clock()

#colores
BLANCO = (255, 255, 255)
AMARILLO = (255, 220, 50)

# Fuentes para los textos en pantalla
fuente_titulo = pygame.font.SysFont("Arial", 40, bold=True)
fuente_subtitulo = pygame.font.SysFont("Arial", 22, bold=True)
fuente = pygame.font.SysFont("Arial", 28, bold=True)

#Carga de imagenes

#Fondo
img_fondo=pygame.image.load("Fondo.jpg").convert()
img_fondo=pygame.transform.scale(img_fondo,(600,400))

#Estrella
img_Estrella=pygame.image.load("Estrella.png").convert_alpha()
img_Estrella=pygame.transform.scale(img_Estrella,(40,40))

#Canasta
img_Canasta=pygame.image.load("canasta.png").convert_alpha()
img_Canasta=pygame.transform.scale(img_Canasta,(100,80))

# ==========================================
# 👾 ETAPA 1: Variable de estado y marcadores
# ==========================================

estado = "INICIO"  # Estados: "INICIO", "JUGANDO", "GAME_OVER"
puntaje = 0
vidas = 3

# ==========================================
# 👾 ETAPA 2: Jugadora y Objetos
# ==========================================

# --- La jugadora: una canasta (un rectangulo por ahora; la imagen viene despues) ---
canasta = pygame.Rect(ANCHO // 2 - 50, ALTO - 90, 100, 80)
VELOCIDAD = 8

# --- Una sola estrella que cae (el prototipo minimo prueba UNA, no muchas) ---
estrella = pygame.Rect(random.randint(0, ANCHO - 40), 0, 40, 40)
VELOCIDAD_CAIDA = 2

# ==========================================
# 🔄 BUCLE PRINCIPAL
# ==========================================

corriendo = True
while corriendo:

    # --------------------------------------
    # 🔴 ETAPA: Eventos y Movimiento
    # --------------------------------------
    # 1) Eventos: cerrar la ventana (Clase 04). ESC tambien cierra.
    for evento in pygame.event.get():
        if evento.type == pygame.QUIT:
          corriendo = False
        if evento.type == pygame.KEYDOWN:
            if evento.key == pygame.K_ESCAPE:
              corriendo = False
            if estado == "INICIO" and evento.key == pygame.K_SPACE:
              estado = "JUGANDO"
            elif estado in ("GANASTE", "GAME_OVER") and evento.key == pygame.K_SPACE:
              puntaje = 0
              vidas = 3
              estrella.x = random.randint(0, ANCHO - 40)
              estrella.y = 0
              canasta.x = ANCHO // 2 - 50
              estado = "JUGANDO"

           ### 🚨 NUEVO: Reiniciar desde GAME_OVER al presionar ESPACIO

    # 🛠️ TODO 3: Mueve la canasta a la izquierda con K_LEFT y a la derecha con K_RIGHT
    # 2) Movimiento continuo de la canasta con las flechas (Clase 05)
    if estado == "JUGANDO":
      teclas = pygame.key.get_pressed()
      if teclas[pygame.K_LEFT]:
        canasta.x -= VELOCIDAD
      if teclas[pygame.K_RIGHT]:
        canasta.x += VELOCIDAD

      # No dejar que la canasta salga de la pantalla (limites, Clase 05)
      canasta.clamp_ip(pantalla.get_rect())

      # 3) La estrella cae un poco cada frame
      estrella.y += VELOCIDAD_CAIDA

      # 4) MECANICA PRINCIPAL: ¿la canasta atrapo la estrella? (colision, Clase 06)
      if canasta.colliderect(estrella):
        puntaje +=10
        estrella.x = random.randint(0, ANCHO - 40)
        estrella.y = 0

        if puntaje >= 150:
          estado = "GANASTE"

      # Si la estrella se cae por abajo sin ser atrapada, tambien reaparece arriba.
      if estrella.y > ALTO:
        vidas -= 1
        estrella.x = random.randint(0, ANCHO - 40)
        estrella.y = 0
        # Cambia al estado GAME_OVER en lugar de cerrar el juego
        if vidas <= 0:
          estado = "GAME_OVER"

    # --------------------------------------
    # 🖼️ ETAPA: Dibujar todo
    # --------------------------------------
    pantalla.blit(img_fondo, (0, 0))
    if estado == "INICIO":
        # Renderizar textos de bienvenida
        texto_instruccion = fuente_subtitulo.render("Presiona ESPACIO para comenzar", True, AMARILLO)
        texto_controles = fuente_subtitulo.render("Usa las flechas ◄ ► para mover la canasta", True, AMARILLO)

        # Centrar cada texto usando get_rect(center=...)
        rect_instruccion = texto_instruccion.get_rect(center=(ANCHO // 2, ALTO // 2 + 10))
        rect_controles = texto_controles.get_rect(center=(ANCHO // 2, ALTO // 2 + 50))

        pantalla.blit(texto_instruccion, rect_instruccion)
        pantalla.blit(texto_controles, rect_controles)

    elif estado == "JUGANDO":
        pantalla.blit(img_Canasta, canasta)
        pantalla.blit(img_Estrella, estrella)

        texto_vidas = fuente.render(f"Vidas: {vidas}", True, BLANCO)
        pantalla.blit(texto_vidas, (15, 15))

        texto_puntaje = fuente.render(f"Puntaje: {puntaje}", True, BLANCO)
        rect_puntaje = texto_puntaje.get_rect(topright=(ANCHO - 15, 15))
        pantalla.blit(texto_puntaje,rect_puntaje)

    elif estado == "GANASTE":
        texto_ganaste = fuente_titulo.render("Felicidades Ganaste!", True, AMARILLO)
        texto_puntaje_final = fuente.render(f"Puntaje Final: {puntaje}", True, BLANCO)
        texto_reiniciar = fuente_subtitulo.render(f"Presiona Espacio para jugar de nuevo", True, BLANCO)

        # Centrar cada texto usando get_rect(center=...)
        rect_ganaste = texto_ganaste.get_rect(center=(ANCHO // 2, ALTO // 2 + 10))
        rect_puntaje_final = texto_puntaje_final.get_rect(center=(ANCHO // 2, ALTO // 2 + 50))
        rect_reiniciar = texto_reiniciar.get_rect(center=(ANCHO // 2, ALTO // 2 + 70))

        pantalla.blit(texto_ganaste, rect_ganaste)
        pantalla.blit(texto_puntaje_final, rect_puntaje_final)
        pantalla.blit(texto_reiniciar, rect_reiniciar)

    elif estado == "GAME_OVER":
        texto_gameover = fuente_titulo.render("GAME OVER", True, AMARILLO)
        texto_puntaje_final = fuente.render(f"Puntaje Final: {puntaje}", True, BLANCO)
        texto_reiniciar = fuente_subtitulo.render(f"Presiona Espacio para jugar de nuevo", True, BLANCO)

        # Centrar cada texto usando get_rect(center=...)
        rect_gameover = texto_gameover.get_rect(center=(ANCHO // 2, ALTO // 2 + 10))
        rect_puntaje_final = texto_puntaje_final.get_rect(center=(ANCHO // 2, ALTO // 2 + 50))
        rect_reiniciar = texto_reiniciar.get_rect(center=(ANCHO // 2, ALTO // 2 + 70))

        pantalla.blit(texto_gameover, rect_gameover)
        pantalla.blit(texto_puntaje_final, rect_puntaje_final)
        pantalla.blit(texto_reiniciar, rect_reiniciar)

     # 🚨 NUEVO: Pantalla de GAME OVER

    pygame.display.flip()
    reloj.tick(60)

pygame.quit()