"""Un PyGame listo para usar en Google Colab.

En tu computador escribirías:

    import pygame

Aquí escribes:

    from colab_window import pygame

…y de ahí en adelante **todo es PyGame normal**. El juego que escribas funciona igual
en los dos lados.

¿Qué hace este archivo por ti?
------------------------------
La máquina de Google Colab no tiene pantalla ni teclado: es un computador sin monitor,
en algún lugar del mundo. Este módulo le consigue una pantalla que existe solo en
memoria (Xvfb) y te la muestra en el navegador; tus teclas viajan de vuelta hasta ella.

Para que no tengas que acordarte de nada, deja `pygame.display.set_mode()` preparado:
cuando lo llames, él monta la pantalla del tamaño que pediste y te la muestra. En tu
computador no hace nada de esto, porque no hace falta.

Esta es la ÚNICA pieza que no escribirías en un juego de verdad. Por eso vive aquí,
en un archivo aparte, y no mezclada con tu juego.
"""

import os
import subprocess
import sys
import time
import warnings

__all__ = ["pygame", "diagnostico", "mostrar"]

PUERTO_VNC = 5900
PUERTO_WEB = 6080
NUMERO = ":1"

_mostrada = False


# ─────────────────────────── PyGame ───────────────────────────
def _traer_pygame():
    """Importa PyGame, instalándolo si falta y sin el ruido de sus dependencias."""
    warnings.filterwarnings("ignore", message=".*pkg_resources is deprecated.*")
    try:
        import pygame as _pg
    except ImportError:
        print("Instalando PyGame…")
        subprocess.run([sys.executable, "-m", "pip", "install", "-q", "pygame"],
                       check=False)
        import pygame as _pg
    return _pg


pygame = _traer_pygame()


# ─────────────────────────── ¿dónde estamos? ───────────────────────────
def en_colab():
    """¿Estamos en Google Colab o en un computador con pantalla?"""
    try:
        import google.colab  # noqa: F401
        return True
    except ImportError:
        return False


def _pantalla_andando():
    """¿La pantalla virtual ya está montada? Para no volver a montarla."""
    if os.environ.get("DISPLAY") != NUMERO:
        return False
    vivo = subprocess.run(["pgrep", "-f", "Xvfb " + NUMERO],
                          capture_output=True, text=True)
    return bool(vivo.stdout.strip())


def _corre(cmd):
    return subprocess.run(cmd, shell=True, capture_output=True, text=True)


# ─────────────────────────── montar la pantalla ───────────────────────────
def _montar(ancho, alto):
    """Instala y enciende la pantalla virtual. Devuelve True si quedó andando."""
    import shutil

    faltan = [p for p in ("Xvfb", "x11vnc") if shutil.which(p) is None]
    if faltan:
        print("Preparando la pantalla… (~1 minuto, solo la primera vez)")
        _corre("DEBIAN_FRONTEND=noninteractive apt-get -qq update")
        paquetes = {"Xvfb": "xvfb", "x11vnc": "x11vnc"}
        r = _corre("DEBIAN_FRONTEND=noninteractive apt-get -qq install -y "
                   + " ".join(paquetes[p] for p in faltan))
        todavia = [p for p in faltan if shutil.which(p) is None]
        if todavia:
            print("No pude instalar: " + ", ".join(todavia))
            print((r.stderr or r.stdout or "(sin mensaje)")[-1200:])
            return False

    if shutil.which("websockify") is None:
        r = _corre(sys.executable + " -m pip install -q websockify")
        if shutil.which("websockify") is None:
            print("No pude instalar websockify:")
            print((r.stderr or r.stdout or "(sin mensaje)")[-800:])
            return False

    if not os.path.isfile("/opt/noVNC/vnc.html"):
        _corre("rm -rf /opt/noVNC")
        r = _corre("git clone -q --depth 1 https://github.com/novnc/noVNC.git /opt/noVNC")
        if not os.path.isfile("/opt/noVNC/vnc.html"):
            print("No pude bajar el visor:")
            print((r.stderr or r.stdout or "(sin mensaje)")[-800:])
            return False

    _corre("pkill -f 'Xvfb " + NUMERO + "' ; pkill x11vnc ; pkill websockify")
    time.sleep(1)
    callado = dict(stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    subprocess.Popen(["Xvfb", NUMERO, "-screen", "0",
                      str(ancho) + "x" + str(alto) + "x24", "-ac"], **callado)
    time.sleep(2)
    subprocess.Popen(["x11vnc", "-display", NUMERO, "-nopw", "-forever", "-shared",
                      "-rfbport", str(PUERTO_VNC), "-quiet"], **callado)
    time.sleep(1)
    subprocess.Popen(["websockify", "--web=/opt/noVNC", str(PUERTO_WEB),
                      "localhost:" + str(PUERTO_VNC)], **callado)
    time.sleep(2)
    os.environ["DISPLAY"] = NUMERO
    return True


def mostrar(otra_vez=False):
    """Muestra la pantalla aquí abajo. Se llama sola al abrir la ventana del juego.

    Si la llamas de nuevo NO agrega otra copia: dos visores mirando la misma pantalla
    la hacen parpadear. Si de verdad quieres otra, usa mostrar(otra_vez=True).
    """
    global _mostrada
    if not en_colab():
        return
    from google.colab import output
    if _mostrada and not otra_vez:
        return
    _mostrada = True
    print("Esta es tu pantalla. Haz clic encima antes de apretar las flechas.")
    output.serve_kernel_port_as_iframe(
        PUERTO_WEB, path="/vnc.html?autoconnect=true&resize=scale&reconnect=true",
        height="560")
    enlace = "▶ Abrirla en otra pestaña (se juega mejor)"
    ruta = "/vnc.html?autoconnect=true&resize=scale"
    try:
        try:
            output.serve_kernel_port_as_window(PUERTO_WEB, path=ruta,
                                               anchor_text=enlace, skip_warning=True)
        except TypeError:
            output.serve_kernel_port_as_window(PUERTO_WEB, path=ruta, anchor_text=enlace)
    except Exception:
        pass          # si no se puede abrir pestaña, queda el visor de arriba


# ─────────── dejar set_mode() preparado, para que tú no hagas nada ───────────
# Guardamos el set_mode de verdad UNA sola vez. Si este archivo se vuelve a importar,
# no queremos envolver lo ya envuelto: saldria todo duplicado.
_set_mode_original = getattr(pygame.display.set_mode, "_original", None) \
                     or pygame.display.set_mode


def _set_mode(size=(0, 0), *args, **kwargs):
    """El set_mode() de siempre, pero consiguiendo antes una pantalla donde abrirse."""
    if en_colab():
        ancho, alto = (size if size and size != (0, 0) else (800, 600))[:2]
        if not _pantalla_andando():
            if not _montar(ancho, alto):
                raise RuntimeError(
                    "No se pudo preparar la pantalla. Llama a "
                    "colab_window.diagnostico() para ver qué falta.")

    # Un notebook no arranca de cero como un programa: puede quedar una pantalla
    # abierta de la corrida anterior. La soltamos para abrir la nueva limpia.
    if pygame.display.get_init():
        pygame.display.quit()
    pygame.display.init()

    superficie = _set_mode_original(size, *args, **kwargs)
    mostrar()
    return superficie


_set_mode._original = _set_mode_original      # marca: este ya viene preparado
pygame.display.set_mode = _set_mode


# ─────────────────────────── por si algo falla ───────────────────────────
def diagnostico():
    """Si algo no funciona, llama a esto: dice qué pieza falta."""
    import shutil
    print("── ¿Dónde estamos? ──")
    print("  Colab:", en_colab())
    print("\n── Programas ──")
    for p in ("Xvfb", "x11vnc", "websockify", "git"):
        print("  " + p.ljust(12) + str(shutil.which(p) or "FALTA"))
    print("  " + "visor".ljust(12) +
          ("ok" if os.path.isfile("/opt/noVNC/vnc.html") else "FALTA"))
    print("\n── Procesos ──")
    for p in ("Xvfb", "x11vnc", "websockify"):
        r = subprocess.run(["pgrep", "-fa", p], capture_output=True, text=True)
        print("  " + p.ljust(12) + ("andando" if r.stdout.strip() else "NO esta corriendo"))
    print("\n── PyGame ──")
    print("  version:", pygame.version.ver)
    print("  display iniciado:", pygame.display.get_init())
    if pygame.display.get_init():
        print("  driver:", pygame.display.get_driver())
    print("  DISPLAY =", os.environ.get("DISPLAY", "(sin definir)"))
