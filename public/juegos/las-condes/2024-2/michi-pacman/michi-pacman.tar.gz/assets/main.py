import ast
import asyncio
import os
import sys
import types
import traceback
import pygame

GAME_FILE = "game.py"

if "pygame.locals" not in sys.modules:
    locals_mod = types.ModuleType("pygame.locals")
    for attr in dir(pygame):
        if attr.isupper():
            setattr(locals_mod, attr, getattr(pygame, attr))
    sys.modules["pygame.locals"] = locals_mod


def await_asyncio_sleep(args):
    """Crea el nodo: await asyncio.sleep(<args>)"""
    return ast.Await(
        value=ast.Call(
            func=ast.Attribute(
                value=ast.Name(id="asyncio", ctx=ast.Load()),
                attr="sleep",
                ctx=ast.Load()
            ),
            args=args,
            keywords=[]
        )
    )


def es_bucle_de_juego(nodo_while):
    """Un while es el bucle del juego si dentro actualiza la pantalla."""
    for nodo in ast.walk(nodo_while):
        if (isinstance(nodo, ast.Call) and isinstance(nodo.func, ast.Attribute)
                and nodo.func.attr in ("flip", "update")):
            return True
    return False


def ceder_control(nodo_while):
    """Pone await asyncio.sleep(0) al PRINCIPIO del while, para que un
    'continue' dentro del bucle no se lo salte."""
    nodo_while.body.insert(0, ast.Expr(value=await_asyncio_sleep([ast.Constant(value=0)])))


def nombres_llamados(funcion):
    return {n.func.id for n in ast.walk(funcion)
            if isinstance(n, ast.Call) and isinstance(n.func, ast.Name)}


class HacerAsync(ast.NodeTransformer):
    """Dentro del código async:
    - time.sleep(x)      ->  await asyncio.sleep(x)
    - funcion_async(...) ->  await funcion_async(...)
    No entra en funciones normales, clases ni lambdas (ahí no se puede usar await).
    """

    def __init__(self, funciones_async):
        self.funciones_async = funciones_async

    def visit_FunctionDef(self, node):
        return node

    visit_ClassDef = visit_FunctionDef
    visit_Lambda = visit_FunctionDef

    def visit_Call(self, node):
        self.generic_visit(node)
        func = node.func
        if (isinstance(func, ast.Attribute) and func.attr == "sleep"
                and isinstance(func.value, ast.Name) and func.value.id == "time"):
            return await_asyncio_sleep(node.args)
        if isinstance(func, ast.Name) and func.id in self.funciones_async:
            return ast.Await(value=node)
        return node


def transformar(tree):
    funciones = {n.name: n for n in tree.body if isinstance(n, ast.FunctionDef)}

    # 1. Funciones de nivel superior que tienen el bucle del juego dentro
    funciones_async = set()
    for nombre, funcion in funciones.items():
        for nodo in ast.walk(funcion):
            if isinstance(nodo, ast.While) and es_bucle_de_juego(nodo):
                ceder_control(nodo)
                funciones_async.add(nombre)

    # 2. Las funciones que llaman a una función async también deben ser async
    cambio = True
    while cambio:
        cambio = False
        for nombre, funcion in funciones.items():
            if nombre not in funciones_async and nombres_llamados(funcion) & funciones_async:
                funciones_async.add(nombre)
                cambio = True

    # 3. Convertirlas en "async def"
    for i, nodo in enumerate(tree.body):
        if isinstance(nodo, ast.FunctionDef) and nodo.name in funciones_async:
            nuevo = ast.AsyncFunctionDef(
                name=nodo.name, args=nodo.args, body=nodo.body,
                decorator_list=nodo.decorator_list, returns=nodo.returns,
                type_comment=None
            )
            tree.body[i] = ast.copy_location(nuevo, nodo)

    # 4. Bucles while de nivel superior (como en dia-lluvioso, sushi y cuphead)
    for nodo in tree.body:
        if isinstance(nodo, ast.While):
            ceder_control(nodo)

    # 5. Agregar los await que faltan
    return HacerAsync(funciones_async).visit(tree)


async def main():
    try:
        base_dir = os.path.dirname(os.path.abspath(__file__))
        os.chdir(base_dir)
        game_path = os.path.join(base_dir, GAME_FILE)

        with open(game_path, "r", encoding="utf-8") as f:
            source = f.read()

        tree = transformar(ast.parse(source))

        async_func = ast.AsyncFunctionDef(
            name="_game_runner",
            args=ast.arguments(posonlyargs=[], args=[], kwonlyargs=[], kw_defaults=[], defaults=[]),
            body=tree.body,
            decorator_list=[]
        )

        wrapper_module = ast.Module(body=[async_func], type_ignores=[])
        ast.fix_missing_locations(wrapper_module)

        namespace = {"asyncio": asyncio, "__name__": "__main__"}
        exec(compile(wrapper_module, filename=GAME_FILE, mode="exec"), namespace)
        await namespace["_game_runner"]()

    except Exception:
        traceback.print_exc()

asyncio.run(main())
