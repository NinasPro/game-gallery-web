import pygame
import sys
import random
import time


pygame.init()


pygame.mixer.music.load("fondo.ogg")
pygame.mixer.music.set_volume(0.5)
pygame.mixer.music.play(-1)


sonido_objeto = pygame.mixer.Sound("sonido_objeto.ogg")
canal_sonido_objeto = pygame.mixer.Channel(1)


Ancho = 800
Alto = 800


Ventana = pygame.display.set_mode((Ancho, Alto))
pygame.display.set_caption("Michi-Pacman")
pygame.font.init()
fuente = pygame.font.Font(None, 36)




class Laberinto:


  def __init__(self):
    self.paredes = [
     
      #Horizontal
        pygame.Rect(0, 0, 780, 20),  # 1: Línea Superior principal
        pygame.Rect(0, 650, 800, 20),  # 2: Línea Inferior principal
        #pygame.Rect(0, 390, 800, 5), #Línea central guía


      #cuadrante izq sup H
        pygame.Rect(70, 70, 220, 20),  # 2da H
        pygame.Rect(70, 140, 100, 20),  # 3ra H
        pygame.Rect(140, 210, 98, 20),  # 4ta H
        pygame.Rect(140, 280, 345, 20),  # 5ta H
        pygame.Rect(0, 350, 310, 20), #6ta H
        pygame.Rect(0, 500, 400, 20), #7ta H
       
      #Cuadrante der sup H
        pygame.Rect(360, 70, 380, 20), # 2da H
        pygame.Rect(430, 140, 195, 20), # 3ra H
        pygame.Rect(430, 160 + 50, 120, 20), # 4ta H
        pygame.Rect(430+120+60, 160 + 50, 80, 20), # 5ta H
        pygame.Rect(550, 400 , 320, 20), # 6ta H
        pygame.Rect(600, 580, 220, 20), # 7ta H


      #Vertical
        pygame.Rect(780, 0, 20, 650),  #Línea Costado derecho principal
        pygame.Rect(0, 0, 20, 650),  #Línea Costado izquierdo principal
       # pygame.Rect(390, 0, 5, 800), #Línea Central Guía


      #Cuadrante izq sup V
        pygame.Rect(70, 160, 20, 200),  # 2da V
        pygame.Rect(220, 0, 20, 230),  # 3ra V
        pygame.Rect(290, 70, 20, 160),  # 4ta V
        pygame.Rect(290, 420, 20, 160),  # 5ta V
        pygame.Rect(360, 70, 20, 380),  # 6Ta V
        pygame.Rect(90, 420, 20, 160),  # 5ta V


      #Cuadrante der sup V
        pygame.Rect(450, 500, 20, 150), #2da V sup
        pygame.Rect(360+20+50, 140, 20, 70), #2da V inf
        pygame.Rect(530, 160+60, 20, 200), # 3ra V
        pygame.Rect(535+70, 160+120, 20, 200), # 4ra V
        pygame.Rect(535+90+50, 90, 20, 200) # 4ra V
    ]


  def dibujar(self, ventana):
    for pared in self.paredes:
      pygame.draw.rect(ventana, (51, 255, 212), pared)






class Jugador:


  def __init__(self):
    self.x = 21
    self.y = 21
    self.imagen = pygame.image.load("gatito.png")
    self.imagen = pygame.transform.scale(self.imagen, (40, 40))
    self.rect = self.imagen.get_rect()
    self.rect.topleft = (self.x, self.y)
    self.velocidad = 1


  def dibujar(self, ventana):
    ventana.blit(self.imagen, (self.rect.x, self.rect.y))


  def movimiento(self, paredes):
    posicion_original = self.rect.copy()
    tecla_presionada = pygame.key.get_pressed()


    if tecla_presionada[pygame.K_LEFT]:
      self.rect.x -= self.velocidad
    if tecla_presionada[pygame.K_RIGHT]:
      self.rect.x += self.velocidad
    if tecla_presionada[pygame.K_DOWN]:
      self.rect.y += self.velocidad
    if tecla_presionada[pygame.K_UP]:
      self.rect.y -= self.velocidad


    for pared in paredes:
      if self.rect.colliderect(pared):
        self.rect = posicion_original
        break


    self.x = self.rect.x
    self.y = self.rect.y




class Objeto:


  def __init__(self, x, y, nombre, tamano, color_rgb):
    self.x = x
    self.y = y
    self.tamano = tamano
    self.color = color_rgb
    self.rect = pygame.Rect(self.x, self.y, tamano, tamano)
    self.nombre = nombre
    self.noencontrado = True


  def dibujar(self, superficie):
    if self.noencontrado:
      pygame.draw.rect(superficie, self.color, self.rect)


  def coalicion(self, jugador):
    if self.rect.colliderect(jugador.rect) and self.noencontrado:
      self.noencontrado = False
      canal_sonido_objeto.play(sonido_objeto)
      return True
    return False




def generar_posicion_aleatoria(ancho, alto, tamano, objetos_existentes,
                               paredes, jugador):
  invalidez = True
  while invalidez:
    posicion_x = random.randint(20, 780 - tamano)
    posicion_y = random.randint(20, 690 - tamano)
    nuevo_rect = pygame.Rect(posicion_x, posicion_y, tamano, tamano)


    colisiona_con_pared = False
    for pared in paredes:
      if nuevo_rect.colliderect(pared):
        colisiona_con_pared = True
        break


    if colisiona_con_pared:
      continue


    if nuevo_rect.colliderect(jugador.rect):
      continue


    colisiona_con_objeto = False
    for objeto in objetos_existentes:
      if nuevo_rect.colliderect(objeto.rect):
        colisiona_con_objeto = True
        break


    if colisiona_con_objeto:
      continue


    return posicion_x, posicion_y




def crear_objetos_por_nivel(nivel, paredes, jugador):
  objetos = []
  cantidad_objetos = nivel + 2
  for i in range(cantidad_objetos):
    color = random.randint(50,
                           255), random.randint(50,
                                                255), random.randint(50, 255)
    x, y = generar_posicion_aleatoria(Ancho, Alto, 20, objetos, paredes,
                                      jugador)
    objeto = Objeto(x, y, "churu", 20, color)
    objetos.append(objeto)


  return objetos




def juego():
  nivel = 4
  contador = 0
  puntaje = 0
  laberinto = Laberinto()
  jugador = Jugador()
  objetos = crear_objetos_por_nivel(nivel, laberinto.paredes, jugador)
  tiempo_maximo = 25
  tiempo_inicio = time.time()


  while True:
    tiempo_restante = tiempo_maximo - (time.time() - tiempo_inicio)


    for evento in pygame.event.get():
      if evento.type == pygame.QUIT:
        pygame.quit()
        sys.exit()
      elif evento.type == pygame.KEYDOWN and tiempo_restante <= 0:
        if evento.key == pygame.K_r:  # Presiona "R" para reiniciar
          juego()  # Reinicia el juego desde el inicio


    if tiempo_restante <= 0:
      Ventana.fill((0, 0, 0))
      texto_fin = fuente.render("¡Tiempo agotado! Fin del juego", True,
                                (176, 255, 219))
      puntuacion_final = fuente.render(f"Puntuación final: {puntaje}", True,
                                       (176, 176, 255))
      reinicio_texto = fuente.render("Presiona 'R' para reiniciar", True,
                                     (255, 0, 0))
      Ventana.blit(texto_fin, (Ancho // 2 - 150, Alto // 2 - 50))
      Ventana.blit(puntuacion_final, (Ancho // 2 - 150, Alto // 2))
      Ventana.blit(reinicio_texto, (Ancho // 2 - 150, Alto // 2 + 50))
      pygame.display.flip()
      continue


    jugador.movimiento(laberinto.paredes)


    todos_recogidos = True
    for objeto in objetos:
      if objeto.coalicion(jugador):
        contador += 1
        puntaje += 100
      if objeto.noencontrado:
        todos_recogidos = False


    if todos_recogidos:
      nivel += 1
      objetos = crear_objetos_por_nivel(nivel, laberinto.paredes, jugador)
      tiempo_inicio = time.time()


    Ventana.fill((0, 0, 0))
    laberinto.dibujar(Ventana)
    jugador.dibujar(Ventana)
    for objeto in objetos:
      objeto.dibujar(Ventana)


    texto_objetos = fuente.render(f"Objetos encontrados: {contador}", True,
                                  (255, 255, 255))
    texto_puntaje = fuente.render(f"Puntaje: {puntaje}", True, (255, 255, 255))
    tiempo_mostrar = fuente.render(f"Tiempo restante: {int(tiempo_restante)}s",
                                   True, (255, 255, 255))
    Ventana.blit(texto_objetos, (15, Alto - 40))
    Ventana.blit(texto_puntaje, (15, Alto - 80))
    Ventana.blit(tiempo_mostrar, (15, Alto - 120))


    pygame.display.flip()




juego()