# ==============================================================================
# Juego original de: Emilia Leighton y Amanda Calderón
# Curso: Introducción a la Programación en Python - Niñas Pro
# Semestre: 2024 - Segundo Semestre
# ==============================================================================

import pygame
from pygame.locals import QUIT
import pygame.freetype
import sys
import random
import time

pygame.init()
clock = pygame.time.Clock()

#tamaño pantalla
ancho_screen = 600
alto_screen = 344
#colores
BLANCO = (255, 255, 255)
NEGRO = (0, 0, 0)
MORADO = (140, 109, 132)
CELESTE = (107, 120, 191)
GRIS = (209, 204, 195)
NARANJO = (242, 159, 5)

screen = pygame.display.set_mode((ancho_screen, alto_screen))

#fuentes
fuente = pygame.font.SysFont('Arial', 36)
fuente_over = pygame.font.SysFont('Arial', 100)
fuente_reinicio = pygame.font.SysFont('Arial', 30)
fuente_inicio=pygame.font.SysFont('Arial', 30)
fuente_titulo=pygame.font.SysFont('Arial', 80)

boton_jugar=pygame.Rect(ancho_screen//2-100,alto_screen//2+5,200,50)
boton_salir=pygame.Rect(ancho_screen//2-100,alto_screen//2+70,200,50)

texto_boton_jugar=fuente_inicio.render("Jugar",True,BLANCO)
texto_boton_salir=fuente_inicio.render("Salir",True,BLANCO)
texto_boton_reinicio = fuente_reinicio.render("Reiniciar", True, BLANCO)

texto_game_over = fuente_over.render("Game Over", True, BLANCO)
rect_texto_game_over = texto_game_over.get_rect(center=(ancho_screen // 2,alto_screen // 2))

def pantalla_inicio():
    screen.fill(MORADO)

    texto_titulo = fuente_titulo.render("Un día lluvioso", True, BLANCO)
    texto_rect = texto_titulo.get_rect(center=(ancho_screen // 2, alto_screen // 4))
    screen.blit(texto_titulo, texto_rect)
    pygame.draw.rect(screen, CELESTE, boton_jugar)
    pygame.draw.rect(screen, NARANJO, boton_salir)

    screen.blit(texto_boton_jugar, (boton_jugar.x + 50, boton_jugar.y + 10))
    screen.blit(texto_boton_salir, (boton_salir.x + 50, boton_salir.y + 10))

    pygame.display.update()

imagen_corazon = pygame.image.load("corazon.png").convert_alpha()
imagen_corazon = pygame.transform.scale(imagen_corazon, (55, 55))
fondo = pygame.image.load("fondo_juego.jpg")
sprite_gota = pygame.image.load("gota.png").convert_alpha()


class Jugador:
    def __init__(self, x, y, vidas, boosters=[], imagen=None):
        self.x = x
        self.y = y
        self.vidas = vidas
        self.puntaje = 0
        self.image = pygame.image.load("hormiga4.png").convert_alpha()
        self.image = pygame.transform.scale(self.image, (55, 45))
        self.boosters = boosters
        self.rect = pygame.Rect(self.x, self.y, 50, 40)
        self.frames_derecha = []
        self.frames_izquierda = []
        self.frames_actuales = []
        self.frames = 0
        self.spritesheet = Spritesheet("hormiga3.png")
        self.load_frames()

    def load_frames(self):
        for i in range(2):
            frame_derecha = self.spritesheet.get_sprite(i * 474, 0, 474, 365)
            frame_izquierda = self.spritesheet.get_sprite(i * 474, 365, 474, 365)
            self.frames_derecha.append(frame_derecha)
            self.frames_izquierda.append(frame_izquierda)

    def update(self):
        self.frames += 0.2
        if self.frames >= len(self.frames_actuales):
            self.frames = 0
        if len(self.frames_actuales) > 0:
            self.image = self.frames_actuales[int(self.frames)]
            self.image = pygame.transform.scale(self.image, (50, 40))

    def dibujar(self, screen):
        screen.blit(self.image, self.rect)

    def mover(self, dx):
        self.x += dx
        self.rect.x += dx
        if dx < 0:
            self.frames_actuales = self.frames_izquierda
        if dx > 0:
            self.frames_actuales = self.frames_derecha

        if self.x < 0:
            self.x = 0
        elif self.x > ancho_screen - self.rect.width:
            self.x = ancho_screen - self.rect.width

        self.rect.x = self.x
        self.update()

    def chocar(self, objeto, tipo_objeto):
        if self.rect.colliderect(objeto.rect):
            if tipo_objeto == "gota":
                self.vidas -= 1
                return True
            elif tipo_objeto == "azucar":
                self.boosters.append(objeto)
                self.puntaje += objeto.recompensa
                return True
        return False


class Spritesheet:
    def __init__(self, filename):
        self.filename = filename
        self.spritesheet = pygame.image.load(self.filename).convert_alpha()

    def get_sprite(self, x, y, ancho, alto):
        sprite = pygame.Surface((ancho, alto), pygame.SRCALPHA)
        sprite.blit(self.spritesheet, (0, 0), (x, y, ancho, alto))
        return sprite


class Obstaculo(pygame.sprite.Sprite):
    def __init__(self, x, y, daño):
        super().__init__()
        self.y = y
        self.x = x
        self.daño = daño
        self.image = pygame.image.load("gota2.png").convert_alpha()
        self.image = pygame.transform.scale(self.image, (30, 40))
        self.rect = self.image.get_rect(topleft=(self.x, self.y))

    def dibujar(self, screen):
        screen.blit(self.image, self.rect)

    def mover(self):
        self.y += 2
        self.rect.y = int(self.y)


class Potenciador:
    def __init__(self, x, y, recompensa, imagen=None):
        self.x = x
        self.y = y
        self.recompensa = recompensa
        self.image = pygame.image.load("azucar.png").convert_alpha()
        self.image = pygame.transform.scale(self.image, (30, 30))
        self.rect = pygame.Rect(self.x, self.y, 20, 20)
        self.tiempo_en_piso = None
        self.altura_piso = alto_screen - 20

    def dibujar(self, screen):
        screen.blit(self.image, self.rect)

    def mover(self):
        if self.tiempo_en_piso is None:
            self.y += 1
            self.rect.y = int(self.y)
            if self.y >= self.altura_piso:
                self.tiempo_en_piso = time.time()
        else:
            if time.time() - self.tiempo_en_piso >= 2:
                return True
        return False

    def tocar_piso(self):
        if self.y >= self.altura_piso:
            self.en_piso = True
            self.tiempo_en_piso = time.time()


class Sprite(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.image.load("gota2.png")
        self.rect = self.image.get_rect()


sprites = pygame.sprite.Group()
sprite_gota = Sprite()
sprites.add(sprite_gota)

jugando = True

jugador1 = Jugador(x=300, y=300, vidas=3)
boton_reinicio = pygame.Rect(ancho_screen // 2 - 100, alto_screen // 2 + 100, 200, 50)

gotas = []
azucares = []
contador_gotas = 0
contador_azucares = 0
puntaje = 0
tiempo_transcurrido = 0
game_over = False
mostrar_inicio = True
ultimo_tiempo_puntaje = pygame.time.get_ticks()

while jugando:
    for event in pygame.event.get():
        if event.type == QUIT:
            jugando = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                jugador1.mover(-50)
            elif event.key == pygame.K_RIGHT:
                jugador1.mover(50)
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if mostrar_inicio:
                if boton_jugar.collidepoint(event.pos):
                    mostrar_inicio = False
                elif boton_salir.collidepoint(event.pos):
                    jugando = False
            elif game_over:
                if boton_reinicio.collidepoint(event.pos):
                    jugador1 = Jugador(x=300, y=300, vidas=3)
                    gotas = []
                    azucares = []
                    contador_gotas = 0
                    contador_azucares = 0
                    puntaje = 0
                    tiempo_transcurrido = 0
                    game_over = False

    if not game_over and not mostrar_inicio:
        tiempo_actual = pygame.time.get_ticks()
        if tiempo_actual - ultimo_tiempo_puntaje >= 8000:
            jugador1.puntaje += 4
            ultimo_tiempo_puntaje = tiempo_actual

    if mostrar_inicio:
        pantalla_inicio()
    else:
        if jugador1.vidas == 0:
            game_over = True

        if not game_over:
            contador_gotas += 1
            contador_azucares += 1

            if contador_gotas >= 20:
                gota = Obstaculo(x=random.randrange(10, ancho_screen - 10), y=10, daño=1)
                gotas.append(gota)
                contador_gotas = 0

            if contador_azucares >= 40:
                azucar = Potenciador(x=random.randrange(10, ancho_screen - 10), y=10, recompensa=1)
                azucares.append(azucar)
                contador_azucares = 0

            screen.blit(fondo, (0, 0))

            for gota in gotas[:]:
                gota.mover()
                gota.dibujar(screen)
                if jugador1.chocar(gota, "gota"):
                    gotas.remove(gota)

            for azucar in azucares[:]:
                azucar.mover()
                azucar.dibujar(screen)
                if jugador1.chocar(azucar, "azucar"):
                    azucares.remove(azucar)
                elif azucar.mover():
                    azucares.remove(azucar)

            jugador1.dibujar(screen)
            for i in range(jugador1.vidas):
                screen.blit(imagen_corazon, (10 + i * 35, 10))
            texto_puntaje = fuente.render(f"Score: {jugador1.puntaje}", True, NEGRO)
            screen.blit(texto_puntaje, (ancho_screen - 200, 10))

        else:
            screen.fill(MORADO)
            screen.blit(texto_game_over, rect_texto_game_over.topleft)
            texto_puntaje_final = fuente.render(f"Puntaje Final: {jugador1.puntaje}", True, BLANCO)
            rect_texto_puntaje_final = texto_puntaje_final.get_rect(center=(ancho_screen // 2, alto_screen // 2 + 65))
            screen.blit(texto_puntaje_final, rect_texto_puntaje_final.topleft)

            boton_reinicio = pygame.Rect(ancho_screen // 2 - 100, alto_screen // 2 + 100, 200, 50)
            pygame.draw.rect(screen, NARANJO, boton_reinicio)
            rect_texto_reinicio = texto_boton_reinicio.get_rect(center=boton_reinicio.center)
            screen.blit(texto_boton_reinicio, rect_texto_reinicio.topleft)

    pygame.display.update()
    clock.tick(60)

pygame.quit()