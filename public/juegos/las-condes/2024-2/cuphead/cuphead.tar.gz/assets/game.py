import random
import pygame
import sys
import time
import os
pygame.init()

ancho_ventana = 620
largo_ventana = 400

ventana = pygame.display.set_mode((ancho_ventana, largo_ventana))

imagen_fondo = pygame.image.load("fondo_1.png")
imagen_fondo = pygame.transform.scale(imagen_fondo, (ancho_ventana, largo_ventana))

# Cargar música de fondo
# En el navegador (pygbag) el formato recomendado es .ogg; si no existe, usa el .mp3
try:
    if os.path.exists("musica_fondo.ogg"):
        pygame.mixer.music.load("musica_fondo.ogg")
    else:
        pygame.mixer.music.load("musica_fondo.mp3")
    pygame.mixer.music.set_volume(1.0)  # Ajusta el volumen (0.0 a 1.0)
    pygame.mixer.music.play(-1)  # Reproduce la música en bucle infinito (-1)
except pygame.error:
    pass

class Player:
  def __init__(self, x, y, nombre):
      self.rect = pygame.Rect(x, y, 50, 50)
      self.nombre= nombre
      self.speed= 2
      self.imagen = pygame.image.load("cuphead.png")
      self.imagen = pygame.transform.scale(self.imagen, (50, 50))
  def move(self, keys):
      if keys[pygame.K_LEFT]:
        self.rect.x -= self.speed
        if self.rect.x < 0:
          self.rect.x = 0
      if keys[pygame.K_RIGHT]:
        self.rect.x += self.speed
        if self.rect.x > ancho_ventana - 50:
          self.rect.x = ancho_ventana - 50

  def draw(self, ventana):
    #pygame.draw.rect(ventana,(0, 0, 255), self.rect)
    ventana.blit(self.imagen, (self.rect.x, self.rect.y))

class Enemigo:
  def __init__(self, x, y, velocidad, color):
    self.x = x
    self.y = y
    self.radius = 10  # Radio del círculo
    self.speed = velocidad
    self.color = color
    self.imagen = pygame.image.load("bomb.png")
    self.imagen = pygame.transform.scale(self.imagen, (20, 20))
    #self.rect = pygame.Rect(x-self.radius,
    #  y-self.radius,
    #  self.radius*2,
     # self.radius*2)
    self.rect = self.imagen.get_rect(topleft=(self.x, self.y))

  def draw(self, ventana):
      #self.rect.y = self.y-self.radius
      self.y += self.speed
      #pygame.draw.circle(ventana, self.color, (self.x, self.y), self.radius)
      self.rect.topleft = (self.x, self.y)
      ventana.blit(self.imagen, (self.x, self.y))
      #pygame.draw.rect(ventana, (255, 0, 0, 128), self.rect, 2)

clock = pygame.time.Clock()

#Valores iniciales del juego
enemigos = []
contador= 0
color = (255, 0, 0)
velocidad = 1
espacio_entre_enemigos = 60
cantidad_enemigos= 20
nivel = 1

#Creación de instancias iniciales
personaje = Player(285, 350, "Cuphead")
enemigos.append(Enemigo(100, 25, 1, color))

while True:
  for evento in pygame.event.get():
    if evento.type == pygame.QUIT:
      pygame.quit()
      sys.exit()

  # Condicion para crear enemigo
  if contador == espacio_entre_enemigos and len(enemigos) < cantidad_enemigos:
    print("CREAR ENEMIGO")
    enemigos.append(Enemigo(random.randint(25, 600), 25, velocidad, color))
    contador = 0

  #Condicion para avanzar de nivel
  if len(enemigos) == cantidad_enemigos and enemigos[-1].y >= 400:
    print('GANASTE EL NIVEL!')
    nivel += 1
    if nivel == 5:
      font = pygame.font.Font(None, 36)
      text = font.render("Ganaste el juego!!", True, (0, 255, 0))
      ventana.blit(text, (100, 100))
      pygame.display.flip()
      time.sleep(3)
      nivel = 1
      imagen_fondo = pygame.image.load(f'fondo_{nivel}.png')
      imagen_fondo = pygame.transform.scale(imagen_fondo, (ancho_ventana, largo_ventana))
      velocidad = 1
      enemigos = []
      color = (255, 0, 0)
      cantidad_enemigos = 20
      espacio_entre_enemigos = 60
      contador = 0
    else:
      font = pygame.font.Font(None, 36)
      text = font.render("Nivel completado :)", True, (0, 255, 0))
      ventana.blit(text, (100, 100))
      pygame.display.flip()
      time.sleep(3)
      imagen_fondo = pygame.image.load(f'fondo_{nivel}.png')
      imagen_fondo = pygame.transform.scale(imagen_fondo, (ancho_ventana, largo_ventana))
      enemigos = []
      velocidad += 1
      espacio_entre_enemigos = int(espacio_entre_enemigos*0.5)
      contador = 0
      cantidad_enemigos += 10
      color = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))

  keys = pygame.key.get_pressed()
  personaje.move(keys)
  ventana.fill((255, 255, 255))
  ventana.blit(imagen_fondo, (0, 0))
  personaje.draw(ventana)

  #iteramos para cada enemigo
  for enemigo in enemigos:
    #dibujamos el enemigo
    enemigo.draw(ventana)
    #verificamos colisión del enemigo con el personaje y si hay colisión, terminamos el juego
    if personaje.rect.colliderect(enemigo.rect):
      font = pygame.font.Font(None, 36)
      text = font.render("GAME OVER!!", True, (255, 0, 0))
      ventana.blit(text, (100, 100))
      pygame.display.flip()
      time.sleep(3)
      velocidad = 1
      enemigos = []
      color = (255, 0, 0)
      cantidad_enemigos = 20
      espacio_entre_enemigos = 60
      contador = 0
      nivel = 1
      imagen_fondo = pygame.image.load(f'fondo_{nivel}.png')
      imagen_fondo = pygame.transform.scale(imagen_fondo, (ancho_ventana, largo_ventana))

  contador+=1
  pygame.display.flip()
  clock.tick(60)
