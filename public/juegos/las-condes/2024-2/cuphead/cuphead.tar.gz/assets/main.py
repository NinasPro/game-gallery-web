import ast
import asyncio
import os
import sys
import types
import traceback
import pygame

if "pygame.locals" not in sys.modules:
    locals_mod = types.ModuleType("pygame.locals")
    for attr in dir(pygame):
        if attr.isupper():
            setattr(locals_mod, attr, getattr(pygame, attr))
    sys.modules["pygame.locals"] = locals_mod


class SleepAsync(ast.NodeTransformer):
    """Cambia time.sleep(x) por await asyncio.sleep(x) en el código principal.

    En el navegador, time.sleep congela la página y no deja ver lo que se
    dibujó antes (por ejemplo "GAME OVER!!"). Solo se cambia fuera de
    funciones y clases, porque ahí no se puede usar await.
    """

    def visit_FunctionDef(self, node):
        return node

    visit_AsyncFunctionDef = visit_FunctionDef
    visit_ClassDef = visit_FunctionDef
    visit_Lambda = visit_FunctionDef

    def visit_Call(self, node):
        self.generic_visit(node)
        func = node.func
        if (isinstance(func, ast.Attribute) and func.attr == "sleep"
                and isinstance(func.value, ast.Name) and func.value.id == "time"):
            return ast.Await(
                value=ast.Call(
                    func=ast.Attribute(
                        value=ast.Name(id="asyncio", ctx=ast.Load()),
                        attr="sleep",
                        ctx=ast.Load()
                    ),
                    args=node.args,
                    keywords=node.keywords
                )
            )
        return node


async def main():
    try:
        base_dir = os.path.dirname(os.path.abspath(__file__))
        os.chdir(base_dir)
        game_path = os.path.join(base_dir, "game.py")

        with open(game_path, "r", encoding="utf-8") as f:
            source = f.read()

        tree = ast.parse(source)
        tree = SleepAsync().visit(tree)

        for node in tree.body:
            if isinstance(node, ast.While):
                sleep_call = ast.Expr(
                    value=ast.Await(
                        value=ast.Call(
                            func=ast.Attribute(
                                value=ast.Name(id="asyncio", ctx=ast.Load()),
                                attr="sleep",
                                ctx=ast.Load()
                            ),
                            args=[ast.Constant(value=0)],
                            keywords=[]
                        )
                    )
                )
                node.body.append(sleep_call)

        async_func = ast.AsyncFunctionDef(
            name="_game_runner",
            args=ast.arguments(posonlyargs=[], args=[], kwonlyargs=[], kw_defaults=[], defaults=[]),
            body=tree.body,
            decorator_list=[]
        )

        wrapper_module = ast.Module(body=[async_func], type_ignores=[])
        ast.fix_missing_locations(wrapper_module)

        namespace = {"asyncio": asyncio, "__name__": "__main__"}
        exec(compile(wrapper_module, filename="game.py", mode="exec"), namespace)
        await namespace["_game_runner"]()

    except Exception:
        traceback.print_exc()

asyncio.run(main())
