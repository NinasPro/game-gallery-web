import pygame
import sys
import os

# Inicializa Pygame
pygame.init()

# Configura la pantalla
ANCHO, ALTO = 626, 415
PANTALLA = pygame.display.set_mode((ANCHO, ALTO))
pygame.display.set_caption("Sushi Saltarín")
FPS = 60
RELOJ = pygame.time.Clock()

# Fondos de los niveles
fondo_nivel1 = pygame.image.load("bosque_1.png").convert()
fondo_nivel2 = pygame.image.load("ciudad_1.jpg").convert()
fondo_nivel3 = pygame.image.load("mar.png").convert()
fondo_nivel2 = pygame.transform.scale(fondo_nivel2, (ANCHO, ALTO))
fondo_nivel3 = pygame.transform.scale(fondo_nivel3, (ANCHO, ALTO))
fondo_lista = [fondo_nivel1, fondo_nivel2, fondo_nivel3]
fondo_terminado = pygame.image.load("1.png").convert()
fondo_sin_vidas = pygame.image.load("2.png").convert()
fondo_terminado = pygame.transform.scale(fondo_terminado, (ANCHO, ALTO))
fondo_sin_vidas = pygame.transform.scale(fondo_sin_vidas, (ANCHO, ALTO))

# Carga la imagen del sushi
sushi_img = pygame.image.load("sushi_1.1.png")
sushi_rect = sushi_img.get_rect()
sushi_rect.topleft = (20, 325)

# Coordenadas del corazon
alto_corazon1 = 30
ancho_corazon1 = 30

# Carga los corazones (vidas)
corazon1_img = pygame.image.load("corazon_1.png")
corazon1_img = pygame.transform.scale(corazon1_img, (ancho_corazon1, alto_corazon1))

# Vidas del sushi
sushi_vidas = 3

# Crear jugador
class Jugador:
    def __init__(self, nombre, comida, posicion_inicial):
        self.nombre = nombre
        self.animal = comida
        self.posicion = posicion_inicial
        
    def move(self, dx, dy):
        self.posicion[0] += dx
        self.posicion[1] += dy

# Posición inicial del jugador
jugador1 = Jugador("Sushimi", "Sushi", [400, 300])
jugador_x = 0
jugador_y = 100

# Configura el movimiento y el salto
gravity = 0.5
jump_power = -10
sushi_vel_y = 0
sushi_vel_x = 0
is_jumping = False
sushi_speed_x = 60
acceleration = 0.5  # Aceleración suave para movimientos horizontales
friction = -0.1

# Coordenadas del jarron
x_jarron = 625
y_jarron = 315
alto_jarron = 30
ancho_jarron = 30

# Coordenadas del panal
x_panal = 625
y_panal = 280
alto_panal = 30
ancho_panal = 30

# Coordenadas del celular
x_celular = 625
y_celular = 315
alto_celular = 30
ancho_celular = 30

# Coordenadas de la alga
x_alga = 625
y_alga = 315
alto_alga = 30
ancho_alga = 30

# Coordenadas del cofre
x_cofre = 625
y_cofre = 315
alto_cofre = 30
ancho_cofre = 30

# Coordenadas de la botella
x_botella = 625
y_botella = 315
alto_botella = 30
ancho_botella = 30

# Crear obstaculos
class Obstaculo:
    def __init__(self, posicion_inicial, tipo, imagen, ancho, alto):
        self.posicion = posicion_inicial
        self.tipo = tipo
        try:
            self.imagen = pygame.image.load(imagen)
            self.imagen = pygame.transform.scale(self.imagen, (ancho, alto))
        except (FileNotFoundError, pygame.error):
            # Si falta la imagen (ej: cofre.png), dibuja un cofre simple
            self.imagen = pygame.Surface((ancho, alto))
            self.imagen.fill((139, 90, 43))
            pygame.draw.rect(self.imagen, (218, 165, 32), (0, alto // 3, ancho, 4))
            pygame.draw.rect(self.imagen, (218, 165, 32), (ancho // 2 - 3, alto // 3, 6, 8))
        self.rect = self.imagen.get_rect(topleft=self.posicion)
    
    def move(self, dx):
        self.rect.x += dx

# Crear imágenes de los obstáculos
jarron_img = "jarrondemiel.png"
panal_img = "panaldeabejas.png"
celular_img = "celular.png"
botella_img = "botella.png"
alga_img = "alga.png"
cofre_img = "cofre.png"

# Crear lista para obstaculos
obstaculos = []
alternar = True  # Variable para alternar entre obstáculos

# Tiempo de creación de obstáculos
tiempo_inicio = pygame.time.get_ticks()
tiempo_creacion = 2000

# Variables del juego
nivel_actual = 1
tiempo_sin_colision = 0
cambio_de_nivel = 1000

# Musica del juego
# En el navegador (pygbag) el formato recomendado es .ogg; si no existe, usa el .mp3
try:
    if os.path.exists('musica_1.ogg'):
        pygame.mixer.music.load('musica_1.ogg')
    else:
        pygame.mixer.music.load('musica_1.mp3')
    pygame.mixer.music.play(loops=-1, start=0.0)
except pygame.error:
    pass

# Bucle principal del juego
clock = pygame.time.Clock()
running = True

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE and not is_jumping:
                is_jumping = True
                sushi_vel_y = jump_power

    # Aplica gravedad
    if is_jumping:
        sushi_vel_y += gravity
        sushi_rect.y += sushi_vel_y
        if sushi_rect.y >= 325:
            sushi_rect.y = 325
            is_jumping = False

    tiempo_actual = pygame.time.get_ticks()

    if tiempo_actual - tiempo_inicio >= tiempo_creacion:
        if alternar:
            if nivel_actual == 1:
                obstaculo = Obstaculo([x_jarron, y_jarron], "Jarron de Miel", jarron_img, ancho_jarron, alto_jarron)
            elif nivel_actual == 2:
                obstaculo = Obstaculo([x_celular, y_celular], "Celular", celular_img, ancho_celular, alto_celular)
            if nivel_actual == 3:
                obstaculo = Obstaculo([x_alga, y_alga], "Alga", alga_img, ancho_alga, alto_alga)
        else:
            if nivel_actual == 1:    
                obstaculo = Obstaculo([x_panal, y_panal], "Panal de Abejas", panal_img, ancho_panal, alto_panal)
            if nivel_actual == 2:
                obstaculo = Obstaculo([x_botella, y_botella], "Botella de agua", botella_img, ancho_botella, alto_botella)
            if nivel_actual == 3:
                obstaculo = Obstaculo([x_cofre, y_cofre], "Cofre", cofre_img, ancho_cofre, alto_cofre)
    

        tiempo_inicio = tiempo_actual
        alternar = not alternar  # Alterna el tipo de obstáculo

        obstaculos.append(obstaculo)
    
    for obstaculo in obstaculos:
        obstaculo.move(-3)

    for obstaculo in obstaculos:
        if sushi_rect.colliderect(obstaculo.rect):
            sushi_vidas -= 1
            obstaculos.remove(obstaculo)
            if sushi_vidas == 0:
                nivel_actual = 0

    # Cambiar fondo según el nivel 
    if nivel_actual == 1:
        PANTALLA.blit(fondo_nivel1, (0, 0))
    elif nivel_actual == 2:
        PANTALLA.blit(fondo_nivel2, (0, 0))
    else:
        PANTALLA.blit(fondo_nivel3, (0, 0))
              
    if tiempo_actual >= 10000 and tiempo_actual < 20000:
        nivel_actual = 2 
    if tiempo_actual >= 20000 and tiempo_actual <= 30000:
        nivel_actual = 3
    if tiempo_actual >= 30000:
        nivel_actual = 0
        PANTALLA.fill((0, 0, 0))
        PANTALLA.blit(fondo_terminado, (0, 0))
    if nivel_actual != 0:
        if sushi_vidas > 0:
            PANTALLA.blit(sushi_img, sushi_rect.topleft)
            for obstaculo in obstaculos:
                PANTALLA.blit(obstaculo.imagen, obstaculo.rect.topleft)

        # Dibujar corazones
            for i in range(sushi_vidas):
                PANTALLA.blit(corazon1_img, (ANCHO - 40 - (i * 40), 10))
        else:
            PANTALLA.blit(fondo_sin_vidas, (0, 0))
    
    # Control de FPS
    RELOJ.tick(FPS)

    # Actualizar la pantalla
    pygame.display.flip()
    
    # Mantener la tasa de fotogramas
    clock.tick(60)

pygame.mixer.music.stop()
pygame.quit()
sys.exit()
