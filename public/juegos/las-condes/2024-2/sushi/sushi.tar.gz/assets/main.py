import ast
import asyncio
import os
import sys
import types
import traceback
import pygame 

if "pygame.locals" not in sys.modules:
    locals_mod = types.ModuleType("pygame.locals")
    for attr in dir(pygame):
        if attr.isupper():
            setattr(locals_mod, attr, getattr(pygame, attr))
    sys.modules["pygame.locals"] = locals_mod

async def main():
    try:
        base_dir = os.path.dirname(os.path.abspath(__file__))
        os.chdir(base_dir)
        game_path = os.path.join(base_dir, "sushi.py")

        with open(game_path, "r", encoding="utf-8") as f:
            source = f.read()

        tree = ast.parse(source)

        for node in tree.body:
            if isinstance(node, ast.While):
                sleep_call = ast.Expr(
                    value=ast.Await(
                        value=ast.Call(
                            func=ast.Attribute(
                                value=ast.Name(id="asyncio", ctx=ast.Load()),
                                attr="sleep",
                                ctx=ast.Load()
                            ),
                            args=[ast.Constant(value=0)],
                            keywords=[]
                        )
                    )
                )
                node.body.append(sleep_call)

        async_func = ast.AsyncFunctionDef(
            name="_game_runner",
            args=ast.arguments(posonlyargs=[], args=[], kwonlyargs=[], kw_defaults=[], defaults=[]),
            body=tree.body,
            decorator_list=[]
        )

        wrapper_module = ast.Module(body=[async_func], type_ignores=[])
        ast.fix_missing_locations(wrapper_module)

        namespace = {"asyncio": asyncio, "__name__": "__main__"}
        exec(compile(wrapper_module, filename="sushi.py", mode="exec"), namespace)
        await namespace["_game_runner"]()

    except Exception:
        traceback.print_exc()

asyncio.run(main())